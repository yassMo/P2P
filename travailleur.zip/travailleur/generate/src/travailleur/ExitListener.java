/**
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 **/
package travailleur;


/**
 **/
public interface ExitListener {
   //
   // Methods 
   //

   /**
    * exit
    * 
    * @param ev a <code>ExitEvent</code> value : event
    **/
   public  void exit(ExitEvent ev);


}
