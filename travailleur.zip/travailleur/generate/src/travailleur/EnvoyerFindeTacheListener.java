/**
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * null
 * null
 **/
package travailleur;


/**
 **/
public interface EnvoyerFindeTacheListener {
   //
   // Methods 
   //

   /**
    * envoyerFindeTache
    * null
    * @param ev a <code>EnvoyerFindeTacheEvent</code> value : event
    **/
   public  void envoyerFindeTache(EnvoyerFindeTacheEvent ev);


}
