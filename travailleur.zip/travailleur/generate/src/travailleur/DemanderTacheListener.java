/**
 * 
 * 
 * 
 * 
 * null
 * null
 **/
package travailleur;


/**
 **/
public interface DemanderTacheListener {
   //
   // Methods 
   //

   /**
    * demanderTache
    * null
    * @param ev a <code>DemanderTacheEvent</code> value : event
    **/
   public  void demanderTache(DemanderTacheEvent ev);


}
