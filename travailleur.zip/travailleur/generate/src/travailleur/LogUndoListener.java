/**
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 **/
package travailleur;


/**
 **/
public interface LogUndoListener {
   //
   // Methods 
   //

   /**
    * logUndo
    * 
    * @param ev a <code>LogUndoEvent</code> value : event
    **/
   public  void logUndo(LogUndoEvent ev);


}
