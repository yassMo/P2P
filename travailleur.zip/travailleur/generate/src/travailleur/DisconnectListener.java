/**
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 **/
package travailleur;


/**
 **/
public interface DisconnectListener {
   //
   // Methods 
   //

   /**
    * disconnectOut
    * 
    * @param ev a <code>DisconnectEvent</code> value : event
    **/
   public  void disconnectOut(DisconnectEvent ev);


}
