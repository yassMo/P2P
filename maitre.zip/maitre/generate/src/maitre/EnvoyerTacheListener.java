/**
 * 
 * 
 * 
 * 
 * null
 * null
 **/
package maitre;


/**
 **/
public interface EnvoyerTacheListener {
   //
   // Methods 
   //

   /**
    * envoyerTache
    * null
    * @param ev a <code>EnvoyerTacheEvent</code> value : event
    **/
   public  void envoyerTache(EnvoyerTacheEvent ev);


}
