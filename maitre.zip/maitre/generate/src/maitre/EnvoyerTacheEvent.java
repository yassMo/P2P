/**
 * 
 * 
 * 
 * 
 * null
 **/
package maitre;

import inria.smarttools.core.util.*;

/**
 **/
public class EnvoyerTacheEvent extends StEventImpl {
   //
   // Fields 
   //

   /**
    **/
   protected java.lang.String cmd;

   /**
    **/
   public void setCmd(java.lang.String v){
      this.cmd = v;
   }

   public java.lang.String getCmd(){
      return cmd;
   }

   //
   // Constructors 
   //

   /**
    * Constructor
    **/
   public   EnvoyerTacheEvent(java.lang.String cmd){
      setCmd(cmd);
   }

   /**
    * Constructor
    **/
   public   EnvoyerTacheEvent(String adressee, java.lang.String cmd){
      super(adressee);
      setCmd(cmd);
   }


   //
   // Methods 
   //

   /**
    * Return a short description of the EnvoyerTacheEvent object.
    * @return a value of the type 'String' : a string representation of this EnvoyerTacheEvent
    **/
   public  String toString(){
      String res = "EnvoyerTacheEvent";
      return res;
   }


}
