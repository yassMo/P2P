/**
 * 
 * 
 * 
 * 
 **/
package maitre;


/**
 **/
public interface UndoListener {
   //
   // Methods 
   //

   /**
    * undo
    * 
    * @param ev a <code>UndoEvent</code> value : event
    **/
   public  void undo(UndoEvent ev);


}
