/**
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 **/
package maitre;


/**
 **/
public interface ConnectToListener {
   //
   // Methods 
   //

   /**
    * connectTo
    * 
    * @param ev a <code>ConnectToEvent</code> value : event
    **/
   public  void connectTo(ConnectToEvent ev);


}
