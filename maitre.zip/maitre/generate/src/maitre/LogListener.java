/**
 * 
 * 
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 **/
package maitre;


/**
 **/
public interface LogListener {
   //
   // Methods 
   //

   /**
    * log
    * 
    * @param ev a <code>LogEvent</code> value : event
    **/
   public  void log(LogEvent ev);


}
